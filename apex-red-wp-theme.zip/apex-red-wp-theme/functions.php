<?php
/**
 * Apex Red Theme Functions
 *
 * @package Apex_Red
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function apex_red_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'apex-red' ),
        'footer'  => esc_html__( 'Footer Menu', 'apex-red' ),
    ) );
}
add_action( 'after_setup_theme', 'apex_red_setup' );

function apex_red_scripts() {
    wp_enqueue_style( 'apex-red-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Rajdhani:wght@600;700;800&display=swap', array(), null );
    wp_enqueue_style( 'apex-red-style', get_stylesheet_uri(), array(), '1.0.0' );
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1' );
}
add_action( 'wp_enqueue_scripts', 'apex_red_scripts' );