<?php get_header(); ?>
<main style="max-width:1280px; margin:40px auto; padding:0 20px;">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) : the_post();
            the_content();
        endwhile;
    endif;
    ?>
</main>
<?php get_footer(); ?>