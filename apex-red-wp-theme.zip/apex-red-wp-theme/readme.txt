=== Apex Red - High Performance WooCommerce Theme ===
Tags: e-commerce, woocommerce, black, red, dark-mode
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
License: GPLv2 or later

Installation:
1. Go to WordPress Admin -> Appearance -> Themes.
2. Click Add New -> Upload Theme.
3. Select apex-red-wp-theme.zip and click Install Now.
4. Activate the theme and activate WooCommerce.