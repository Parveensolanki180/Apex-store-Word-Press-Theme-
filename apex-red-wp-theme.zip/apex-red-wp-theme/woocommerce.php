<?php get_header(); ?>
<main style="max-width:1280px; margin:40px auto; padding:0 20px;">
    <?php woocommerce_content(); ?>
</main>
<?php get_footer(); ?>