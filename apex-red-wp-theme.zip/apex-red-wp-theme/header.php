<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="apex-header">
    <div style="max-width:1280px; margin:0 auto; padding:15px 20px; display:flex; justify-content:space-between; align-items:center;">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="font-family:'Rajdhani',sans-serif; font-size:24px; font-weight:800; color:#fff;">
            APEX<span style="color:#ef4444;">RED</span>
        </a>
        <nav>
            <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false ) ); ?>
        </nav>
    </div>
</header>