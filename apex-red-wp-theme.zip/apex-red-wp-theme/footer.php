<footer style="background:#000; border-top:1px solid #292d3e; padding:40px 20px; text-align:center; color:#94a3b8; font-size:13px; margin-top:50px;">
    <div style="max-width:1280px; margin:0 auto;">
        <p>&copy; <?php echo date('Y'); ?> APEX RED E-Commerce. Powered by WordPress &amp; WooCommerce.</p>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>